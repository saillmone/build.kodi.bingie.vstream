# -*- coding: utf-8 -*-
import urllib.error
import urllib.request

import xbmc
import xbmcaddon

ADDON_NAME = "Wizard Pack Bingie"
PASTEBIN_RAW_BASE = "https://pastebin.com/raw/"
PASTEBIN_TIMEOUT = 15
PASTEBIN_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/114.0.0.0 Safari/537.36"
)

MAPPING = {
    "omdb": {
        "addon": "plugin.video.tmdb.bingie.helper",
        "setting": "omdb_apikey",
        "label": "OMDb",
        "control_id": 2010,
    },
    "mdblist": {
        "addon": "plugin.video.tmdb.bingie.helper",
        "setting": "mdblist_apikey",
        "label": "MDblist",
        "control_id": 2011,
    },
    "alldebrid_token": {
        "addon": "plugin.video.vstream",
        "setting": "hoster_alldebrid_token",
        "label": "Alldebrid Token",
        "control_id": 2012,
    },
    "alldebrid_url": {
        "addon": "plugin.video.vstream",
        "setting": "urlmain_alldebrid",
        "label": "Alldebrid URL",
        "control_id": 2013,
    },
    "youtube_key": {
        "addon": "plugin.video.youtube",
        "setting": "youtube.api.key",
        "label": "YouTube Key",
        "control_id": 2014,
    },
    "youtube_id": {
        "addon": "plugin.video.youtube",
        "setting": "youtube.api.id",
        "label": "YouTube ID",
        "control_id": 2015,
    },
    "youtube_secret": {
        "addon": "plugin.video.youtube",
        "setting": "youtube.api.secret",
        "label": "YouTube Secret",
        "control_id": 2016,
    },
}


def _normalize_paste_id(paste_id):
    """Extrait l'identifiant Pastebin depuis un ID brut ou une URL complète."""
    paste_id = (paste_id or "").strip()
    if not paste_id:
        return paste_id
    if "pastebin.com" in paste_id.lower():
        paste_id = paste_id.rstrip("/").split("/")[-1]
    return paste_id.strip()


def fetch_pastebin(paste_id):
    """Télécharge le contenu brut d'un paste Pastebin."""
    paste_id = _normalize_paste_id(paste_id)
    if not paste_id:
        raise ValueError("ID Pastebin vide.")
    if "/" in paste_id or ".." in paste_id:
        raise ValueError("Identifiant Pastebin invalide.")

    url = f"{PASTEBIN_RAW_BASE}{paste_id}"
    if not url.startswith(PASTEBIN_RAW_BASE):
        raise ValueError(f"URL Pastebin inattendue : {url}")

    req = urllib.request.Request(
        url,
        headers={"User-Agent": PASTEBIN_USER_AGENT},
    )
    try:
        with urllib.request.urlopen(req, timeout=PASTEBIN_TIMEOUT) as resp:
            return resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raise RuntimeError(
            f"HTTP {exc.code} lors de la récupération Pastebin : {exc.reason}"
        ) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Erreur réseau Pastebin : {exc.reason}") from exc
    except UnicodeDecodeError as exc:
        raise RuntimeError("Réponse Pastebin illisible (encodage non UTF-8).") from exc


def parse_pastebin_text(raw):
    """Parse un texte clé=valeur (une paire par ligne, espaces autour du '=' tolérés)."""
    result = {}
    if not raw:
        return result

    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            xbmc.log(
                f"[{ADDON_NAME}] Ligne Pastebin ignorée (pas de '=') : {line}",
                level=xbmc.LOGWARNING,
            )
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key:
            result[key] = value
    return result


def extract_mapped_keys(parsed):
    """Ne conserve que les clés présentes dans MAPPING."""
    if not parsed:
        return {}
    return {key: parsed[key] for key in MAPPING if key in parsed}


def read_key(map_key):
    """Lit une clé API depuis l'addon cible."""
    entry = MAPPING.get(map_key)
    if not entry:
        return ""
    try:
        return xbmcaddon.Addon(entry["addon"]).getSetting(entry["setting"]) or ""
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_NAME}] Lecture impossible {entry['setting']} "
            f"← {entry['addon']} : {exc}",
            level=xbmc.LOGWARNING,
        )
        return ""


def write_key(map_key, value):
    """Écrit une clé API dans l'addon cible."""
    if not value:
        return False

    entry = MAPPING.get(map_key)
    if not entry:
        return False

    try:
        xbmcaddon.Addon(entry["addon"]).setSetting(entry["setting"], value)
        xbmc.log(
            f"[{ADDON_NAME}] Injection {entry['setting']} → {entry['addon']}",
            level=xbmc.LOGINFO,
        )
        return True
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_NAME}] Échec injection {entry['setting']} "
            f"→ {entry['addon']} : {exc}",
            level=xbmc.LOGWARNING,
        )
        return False


def read_all_keys():
    """Lit toutes les clés mappées depuis les addons cibles."""
    return {map_key: read_key(map_key) for map_key in MAPPING}


def write_all_keys(keys_dict):
    """Injecte toutes les clés non vides du dict dans les addons cibles."""
    if not keys_dict:
        return
    for map_key in MAPPING:
        value = keys_dict.get(map_key, "")
        if value:
            write_key(map_key, value)


def mask_value(value):
    """Masque une valeur secrète pour affichage UI."""
    if not value:
        return ""
    if len(value) > 4:
        return f"••••{value[-4:]}"
    return "••••"


def is_complete(keys_dict):
    """True si les 7 clés MAPPING ont une valeur non vide."""
    if not keys_dict:
        return False
    return all(bool(keys_dict.get(map_key, "").strip()) for map_key in MAPPING)
