# -*- coding: utf-8 -*-
import sys

from wizard import Wizard
from settings_dialog import open_settings_dashboard


def _parse_argv():
    params = dict(arg.split("=", 1) for arg in sys.argv[1:] if "=" in arg)
    return params.get("mode", "wizard")


if __name__ == "__main__":
    if _parse_argv() == "dashboard":
        open_settings_dashboard()
    else:
        Wizard().run()
