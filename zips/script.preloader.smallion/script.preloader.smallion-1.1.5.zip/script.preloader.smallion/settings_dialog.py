# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui

from api_keys import (
    MAPPING,
    extract_mapped_keys,
    fetch_pastebin,
    parse_pastebin_text,
    read_all_keys,
    write_all_keys,
    write_key,
)

ADDON_NAME = "Wizard Pack Bingie"
BINGIE_SKIN_ID = "skin.bingie.mod"
CLOSE_ACTIONS = (9, 10, 92, 216, 247, 257, 275, 61467, 61448)
CONTROL_TO_MAP_KEY = {entry["control_id"]: map_key for map_key, entry in MAPPING.items()}


def _dialog_xml_path():
    """Chemin vide = XML du skin actif (comme script.bingie.toolbox DialogSelect)."""
    if xbmc.getSkinDir() == BINGIE_SKIN_ID:
        return ""
    return xbmcaddon.Addon().getAddonInfo("path")


def create_preloader_settings_dialog(**kwargs):
    xml_path = _dialog_xml_path()
    if xml_path == "":
        return PreloaderSettingsDialog(
            PreloaderSettingsDialog.XML,
            xml_path,
            **kwargs,
        )
    return PreloaderSettingsDialog(
        PreloaderSettingsDialog.XML,
        xml_path,
        "Default",
        "1080i",
        **kwargs,
    )


class PreloaderSettingsDialog(xbmcgui.WindowXMLDialog):
    XML = "script-preloader-settings.xml"

    def __init__(self, *args, **kwargs):
        self.mode = kwargs.pop("mode", "wizard")
        initial_values = kwargs.pop("initial_values", {}) or {}
        self.current_keys = {
            map_key: initial_values.get(map_key, "") for map_key in MAPPING
        }
        self.result = None
        super().__init__(*args, **kwargs)

    def onInit(self):
        title = (
            "Configuration des clés API — Installation"
            if self.mode == "wizard"
            else "Configuration des clés API"
        )
        self.getControl(1).setLabel(title)
        self.getControl(1001).setLabel("Importer via Code Pastebin")
        self.getControl(3000).setLabel(
            "Terminer l'installation" if self.mode == "wizard" else "Fermer"
        )

        if self.mode == "dashboard":
            self.current_keys = read_all_keys()
        else:
            self.current_keys = {
                map_key: self.current_keys.get(map_key, "") for map_key in MAPPING
            }

        self._refresh_all_key_buttons()

    def onClick(self, control_id):
        if control_id == 1001:
            self._handle_pastebin_import()
        elif control_id in CONTROL_TO_MAP_KEY:
            self._handle_manual_edit(CONTROL_TO_MAP_KEY[control_id])
        elif control_id == 3000:
            self._finish()

    def onAction(self, action):
        if action.getId() in CLOSE_ACTIONS:
            self._finish()

    def _finish(self):
        if self.mode == "dashboard":
            self.result = read_all_keys()
        else:
            self.result = dict(self.current_keys)
        self.close()

    def _refresh_all_key_buttons(self):
        for map_key in MAPPING:
            self._refresh_key_button(map_key)

    def _refresh_key_button(self, map_key):
        entry = MAPPING[map_key]
        value = self.current_keys.get(map_key, "")
        label2 = value if value else "(vide)"
        self.getControl(entry["control_id"]).setLabel(
            entry["label"],
            label2=label2,
        )

    def _handle_pastebin_import(self):
        paste_id = xbmcgui.Dialog().input("ID Pastebin", type=xbmcgui.INPUT_ALPHANUM)
        if not paste_id:
            return

        try:
            raw = fetch_pastebin(paste_id)
            parsed = parse_pastebin_text(raw)
            extracted = extract_mapped_keys(parsed)
        except (ValueError, RuntimeError) as exc:
            xbmcgui.Dialog().ok(ADDON_NAME, f"Import Pastebin impossible :[CR]{exc}")
            return

        if not extracted:
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                "Aucune clé reconnue dans ce fichier Pastebin.",
            )
            return

        self.current_keys.update(extracted)

        if self.mode == "dashboard":
            write_all_keys(extracted)

        self._refresh_all_key_buttons()
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            f"{len(extracted)} clé(s) importée(s)",
            xbmcgui.NOTIFICATION_INFO,
            3000,
        )

    def _handle_manual_edit(self, map_key):
        entry = MAPPING[map_key]
        current_value = self.current_keys.get(map_key, "")
        keyboard = xbmc.Keyboard(current_value, entry["label"], False)
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return

        value = keyboard.getText().strip()
        self.current_keys[map_key] = value

        if self.mode == "dashboard":
            write_key(map_key, value)

        self._refresh_key_button(map_key)


def open_settings_dashboard():
    dialog = create_preloader_settings_dialog(
        mode="dashboard",
        initial_values={},
    )
    dialog.doModal()
    return dialog.result
