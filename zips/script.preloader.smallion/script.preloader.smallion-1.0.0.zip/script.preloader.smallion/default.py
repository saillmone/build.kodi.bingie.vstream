# -*- coding: utf-8 -*-
import sys
from wizard import Wizard

if __name__ == '__main__':
    Wizard().run()
