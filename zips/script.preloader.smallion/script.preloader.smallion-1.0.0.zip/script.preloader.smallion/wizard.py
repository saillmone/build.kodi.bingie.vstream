import json
import os
import signal
import zipfile
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

GH_OWNER = "saillmone"
GH_REPO  = "build.kodi.bingie.vstream"
GH_TAG   = "v1.1.0"
GH_API_RELEASE = (
    f"https://api.github.com/repos/{GH_OWNER}/{GH_REPO}/releases/tags/{GH_TAG}"
)

TEMP_ZIP   = xbmcvfs.translatePath("special://temp/build.zip")
KODI_HOME  = xbmcvfs.translatePath("special://home/")
CHUNK_SIZE = 8192
ADDON_NAME = "Wizard Pack Bingie"


def inject_setting(addon_id, setting_id, value):
    if not value:
        return
    try:
        xbmcaddon.Addon(addon_id).setSetting(setting_id, value)
    except Exception as exc:
        xbmc.log(
            f"[{ADDON_NAME}] Échec injection {setting_id} → {addon_id} : {exc}",
            level=xbmc.LOGWARNING,
        )


class Wizard:
    def _load_prefs(self, addon):
        return {
            "pref_omdb_key": addon.getSetting("pref_omdb_key"),
            "pref_mdblist_key": addon.getSetting("pref_mdblist_key"),
            "pref_alldebrid_token": addon.getSetting("pref_alldebrid_token"),
            "pref_alldebrid_url": addon.getSetting("pref_alldebrid_url"),
            "pref_yt_key": addon.getSetting("pref_yt_key"),
            "pref_yt_id": addon.getSetting("pref_yt_id"),
            "pref_yt_secret": addon.getSetting("pref_yt_secret"),
        }

    def _prompt_startup(self, dialog, addon):
        configure = dialog.yesno(
            "Installation du Build",
            "Souhaitez-vous renseigner vos clés API et Debrid avant de "
            "lancer le téléchargement ?",
            yeslabel="Configurer",
            nolabel="Installer directement",
        )
        if configure:
            xbmc.executebuiltin("Addon.OpenSettings(script.preloader.smallion)", True)
            if not dialog.yesno(
                ADDON_NAME,
                "Configuration enregistrée.[CR]Lancer l'installation du build ?",
            ):
                return False
        return True

    def _inject_api_keys(self, prefs):
        injections = [
            ("plugin.video.tmdb.bingie.helper", "omdb_apikey", prefs["pref_omdb_key"]),
            ("plugin.video.tmdb.bingie.helper", "mdblist_apikey", prefs["pref_mdblist_key"]),
            ("plugin.video.vstream", "hoster_alldebrid_token", prefs["pref_alldebrid_token"]),
            ("plugin.video.vstream", "urlmain_alldebrid", prefs["pref_alldebrid_url"]),
            ("plugin.video.youtube", "youtube.api.key", prefs["pref_yt_key"]),
            ("plugin.video.youtube", "youtube.api.id", prefs["pref_yt_id"]),
            ("plugin.video.youtube", "youtube.api.secret", prefs["pref_yt_secret"]),
        ]
        for addon_id, setting_id, value in injections:
            inject_setting(addon_id, setting_id, value)
            if value:
                xbmc.log(
                    f"[{ADDON_NAME}] Injection {setting_id} → {addon_id}",
                    level=xbmc.LOGINFO,
                )

    def run(self):
        dialog = xbmcgui.Dialog()
        addon = xbmcaddon.Addon()

        if not self._prompt_startup(dialog, addon):
            return

        prefs = self._load_prefs(addon)

        confirmed = dialog.yesno(
            ADDON_NAME,
            "[B]Installation réservée à un Kodi vierge.[/B][CR][CR]"
            "TOUTE ta configuration actuelle sera supprimée définitivement.[CR]"
            "Kodi se fermera automatiquement à la fin.",
        )
        if not confirmed:
            return

        try:
            self.download()
        except Exception as exc:
            xbmc.log(f"[{ADDON_NAME}] Erreur téléchargement : {exc}", level=xbmc.LOGERROR)
            dialog.ok(f"{ADDON_NAME} — Erreur", f"Échec du téléchargement :[CR]{exc}")
            return

        try:
            self.extract()
        except Exception as exc:
            xbmc.log(f"[{ADDON_NAME}] Erreur extraction : {exc}", level=xbmc.LOGERROR)
            dialog.ok(f"{ADDON_NAME} — Erreur", f"Échec de l'extraction :[CR]{exc}")
            return

        self._enable_addons()
        xbmc.sleep(2000)

        self._inject_api_keys(prefs)

        dialog.ok(
            ADDON_NAME,
            "Installation terminée avec succès.[CR]"
            "Kodi va se fermer pour appliquer les changements.",
        )
        xbmc.log(f"[{ADDON_NAME}] Fermeture forcée du processus Kodi (SIGTERM).", level=xbmc.LOGINFO)
        os.kill(os.getpid(), signal.SIGTERM)

    def _enable_addons(self):
        """Étape 3 — Active explicitement la skin et vStream via JSON-RPC."""
        addons = [
            ("skin.bingie",         "skin Bingie"),
            ("plugin.video.vstream", "vStream"),
        ]
        for addon_id, label in addons:
            payload = (
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
                f'"params":{{"addonid":"{addon_id}","enabled":true}},"id":1}}'
            )
            result = xbmc.executeJSONRPC(payload)
            xbmc.log(f"[{ADDON_NAME}] Activation {label} : {result}", level=xbmc.LOGINFO)

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.log(f"[{ADDON_NAME}] UpdateLocalAddons déclenché.", level=xbmc.LOGINFO)

    def _get_zip_download_url(self):
        """Étape 1 — Interroge l'API GitHub publique pour l'URL directe du ZIP."""
        xbmc.log(f"[{ADDON_NAME}] Étape 1 : récupération de l'URL via {GH_API_RELEASE}", level=xbmc.LOGINFO)
        req = urllib.request.Request(
            GH_API_RELEASE,
            headers={
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "Kodi-Preloader",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                release = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Étape 1 — HTTP {exc.code} sur l'API GitHub : {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Étape 1 — Erreur réseau : {exc.reason}") from exc

        assets = release.get("assets", [])
        xbmc.log(f"[{ADDON_NAME}] Étape 1 : {len(assets)} asset(s) trouvé(s) dans la release {GH_TAG}", level=xbmc.LOGINFO)

        for asset in assets:
            if asset.get("name", "").endswith(".zip"):
                url = asset.get("browser_download_url")
                asset_name = asset.get("name", "")
                if url:
                    xbmc.log(
                        f"[{ADDON_NAME}] Étape 1 : asset sélectionné → '{asset_name}'",
                        level=xbmc.LOGINFO,
                    )
                    return url

        raise RuntimeError(f"Étape 1 — Aucun asset .zip trouvé dans la release '{GH_TAG}'.")

    def download(self):
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Connexion à l'API GitHub...")

        try:
            zip_url = self._get_zip_download_url()
            xbmc.log(f"[{ADDON_NAME}] Étape 2 : téléchargement depuis {zip_url}", level=xbmc.LOGINFO)

            req = urllib.request.Request(
                zip_url,
                headers={"User-Agent": "Kodi-Preloader"},
            )

            progress.update(0, "Téléchargement du build en cours...")

            with urllib.request.urlopen(req) as response:
                total = int(response.headers.get("Content-Length", 0))
                downloaded = 0

                with open(TEMP_ZIP, "wb") as out:
                    while True:
                        if progress.iscanceled():
                            raise RuntimeError("Téléchargement annulé par l'utilisateur.")

                        chunk = response.read(CHUNK_SIZE)
                        if not chunk:
                            break

                        out.write(chunk)
                        downloaded += len(chunk)

                        if total > 0:
                            percent = int(downloaded * 100 / total)
                            mb_done = downloaded / 1_048_576
                            mb_total = total / 1_048_576
                            progress.update(
                                percent,
                                f"Téléchargement : {mb_done:.1f} / {mb_total:.1f} Mo",
                            )
                        else:
                            mb_done = downloaded / 1_048_576
                            progress.update(0, f"Téléchargement : {mb_done:.1f} Mo reçus...")

            xbmc.log(f"[{ADDON_NAME}] Étape 2 : téléchargement terminé ({downloaded / 1_048_576:.1f} Mo)", level=xbmc.LOGINFO)

        except RuntimeError:
            if os.path.exists(TEMP_ZIP):
                os.remove(TEMP_ZIP)
            raise
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Étape 2 — HTTP {exc.code} : {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Étape 2 — Erreur réseau : {exc.reason}") from exc
        finally:
            progress.close()

    def extract(self):
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Extraction de l'archive...")

        try:
            with zipfile.ZipFile(TEMP_ZIP, "r") as zf:
                members = zf.namelist()
                total = len(members)

                for i, member in enumerate(members):
                    zf.extract(member, KODI_HOME)
                    percent = int((i + 1) * 100 / total)
                    progress.update(percent, f"Extraction : {member}")

        except zipfile.BadZipFile as exc:
            raise RuntimeError("Archive ZIP invalide ou corrompue.") from exc
        finally:
            progress.close()
            if os.path.exists(TEMP_ZIP):
                os.remove(TEMP_ZIP)
