import json
import os
import signal
import zipfile
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import api_keys
from api_keys import (
    extract_mapped_keys,
    fetch_pastebin,
    is_complete,
    parse_pastebin_text,
)
from settings_dialog import PreloaderSettingsDialog

GH_OWNER = "saillmone"
GH_REPO  = "build.kodi.bingie.vstream"
GH_TAG = "v1.1.1"
GH_API_RELEASE = (
    f"https://api.github.com/repos/{GH_OWNER}/{GH_REPO}/releases/tags/{GH_TAG}"
)

TEMP_ZIP   = xbmcvfs.translatePath("special://temp/build.zip")
KODI_HOME  = xbmcvfs.translatePath("special://home/")
CHUNK_SIZE = 8192
ADDON_NAME = "Wizard Pack Bingie"


class Wizard:
    def _configure_api_keys(self, dialog):
        extracted_keys = {}
        paste_id = dialog.input("Identifiant Pastebin (laisser vide pour passer)")
        if paste_id:
            paste_success = False
            xbmc.executebuiltin("ActivateWindow(busydialog)")
            try:
                raw = fetch_pastebin(paste_id)
                extracted_keys = extract_mapped_keys(parse_pastebin_text(raw))
                paste_success = True
            except (ValueError, RuntimeError) as exc:
                xbmc.log(
                    f"[{ADDON_NAME}] Échec import Pastebin : {exc}",
                    level=xbmc.LOGWARNING,
                )
                dialog.ok(
                    ADDON_NAME,
                    f"Échec de l'import Pastebin :[CR]{exc}[CR][CR]"
                    "Saisie manuelle disponible.",
                )
            finally:
                xbmc.executebuiltin("Dialog.Close(busydialog)")

            if paste_success and len(extracted_keys) > 0:
                xbmcgui.Dialog().ok(
                    "Import Pastebin",
                    f"{len(extracted_keys)} clés récupérées avec succès.",
                )
            elif paste_success and len(extracted_keys) == 0:
                dialog.ok(
                    ADDON_NAME,
                    "La requête a abouti mais aucune clé valide n'a été trouvée. "
                    "Vérifiez le format de votre code Pastebin.",
                )

        if is_complete(extracted_keys):
            return extracted_keys

        addon_path = xbmcaddon.Addon().getAddonInfo("path")
        settings_dialog = PreloaderSettingsDialog(
            PreloaderSettingsDialog.XML,
            addon_path,
            "Default",
            "1080i",
            mode="wizard",
            initial_values=extracted_keys,
        )
        settings_dialog.doModal()
        return settings_dialog.result or {}

    def run(self):
        dialog = xbmcgui.Dialog()
        keys_dict = self._configure_api_keys(dialog)

        confirmed = dialog.yesno(
            ADDON_NAME,
            "[B]Installation réservée à un Kodi vierge.[/B][CR][CR]"
            "TOUTE ta configuration actuelle sera supprimée définitivement.[CR]"
            "Kodi se fermera automatiquement à la fin.",
        )
        if not confirmed:
            return

        try:
            self.download()
        except Exception as exc:
            xbmc.log(f"[{ADDON_NAME}] Erreur téléchargement : {exc}", level=xbmc.LOGERROR)
            dialog.ok(f"{ADDON_NAME} — Erreur", f"Échec du téléchargement :[CR]{exc}")
            return

        try:
            self.extract()
        except Exception as exc:
            xbmc.log(f"[{ADDON_NAME}] Erreur extraction : {exc}", level=xbmc.LOGERROR)
            dialog.ok(f"{ADDON_NAME} — Erreur", f"Échec de l'extraction :[CR]{exc}")
            return

        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.sleep(5000)
        self._enable_addons()
        api_keys.write_all_keys(keys_dict)

        dialog.ok(
            ADDON_NAME,
            "Installation terminée avec succès.[CR]"
            "Kodi va se fermer pour appliquer les changements.",
        )
        xbmc.log(f"[{ADDON_NAME}] Fermeture forcée du processus Kodi (SIGTERM).", level=xbmc.LOGINFO)
        os.kill(os.getpid(), signal.SIGTERM)

    def _enable_addons(self):
        """Étape 3 — Active explicitement les extensions cibles via JSON-RPC."""
        addons = [
            ("repository.smallion",              "Dépôt smaLLion"),
            ("script.preloader.smallion",        "Wizard smaLLion"),
            ("skin.bingie.mod",                  "Bingie mod pour vStream"),
            ("plugin.video.vstream",             "vStream"),
            ("plugin.video.tmdb.bingie.helper",  "TMDb Bingie Helper"),
            ("plugin.video.youtube",             "YouTube"),
        ]
        for addon_id, label in addons:
            payload = (
                f'{{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled",'
                f'"params":{{"addonid":"{addon_id}","enabled":true}},"id":1}}'
            )
            result = xbmc.executeJSONRPC(payload)
            xbmc.log(f"[{ADDON_NAME}] Activation {label} : {result}", level=xbmc.LOGINFO)

    def _get_zip_download_url(self):
        """Étape 1 — Interroge l'API GitHub publique pour l'URL directe du ZIP."""
        xbmc.log(f"[{ADDON_NAME}] Étape 1 : récupération de l'URL via {GH_API_RELEASE}", level=xbmc.LOGINFO)
        req = urllib.request.Request(
            GH_API_RELEASE,
            headers={
                "Accept": "application/vnd.github.v3+json",
                "User-Agent": "Kodi-Preloader",
            },
        )
        try:
            with urllib.request.urlopen(req) as resp:
                release = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Étape 1 — HTTP {exc.code} sur l'API GitHub : {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Étape 1 — Erreur réseau : {exc.reason}") from exc

        assets = release.get("assets", [])
        xbmc.log(f"[{ADDON_NAME}] Étape 1 : {len(assets)} asset(s) trouvé(s) dans la release {GH_TAG}", level=xbmc.LOGINFO)

        for asset in assets:
            if asset.get("name", "").endswith(".zip"):
                url = asset.get("browser_download_url")
                asset_name = asset.get("name", "")
                if url:
                    xbmc.log(
                        f"[{ADDON_NAME}] Étape 1 : asset sélectionné → '{asset_name}'",
                        level=xbmc.LOGINFO,
                    )
                    return url

        raise RuntimeError(f"Étape 1 — Aucun asset .zip trouvé dans la release '{GH_TAG}'.")

    def download(self):
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Connexion à l'API GitHub...")

        try:
            zip_url = self._get_zip_download_url()
            xbmc.log(f"[{ADDON_NAME}] Étape 2 : téléchargement depuis {zip_url}", level=xbmc.LOGINFO)

            req = urllib.request.Request(
                zip_url,
                headers={"User-Agent": "Kodi-Preloader"},
            )

            progress.update(0, "Téléchargement du build en cours...")

            with urllib.request.urlopen(req) as response:
                total = int(response.headers.get("Content-Length", 0))
                downloaded = 0

                with open(TEMP_ZIP, "wb") as out:
                    while True:
                        if progress.iscanceled():
                            raise RuntimeError("Téléchargement annulé par l'utilisateur.")

                        chunk = response.read(CHUNK_SIZE)
                        if not chunk:
                            break

                        out.write(chunk)
                        downloaded += len(chunk)

                        if total > 0:
                            percent = int(downloaded * 100 / total)
                            mb_done = downloaded / 1_048_576
                            mb_total = total / 1_048_576
                            progress.update(
                                percent,
                                f"Téléchargement : {mb_done:.1f} / {mb_total:.1f} Mo",
                            )
                        else:
                            mb_done = downloaded / 1_048_576
                            progress.update(0, f"Téléchargement : {mb_done:.1f} Mo reçus...")

            xbmc.log(f"[{ADDON_NAME}] Étape 2 : téléchargement terminé ({downloaded / 1_048_576:.1f} Mo)", level=xbmc.LOGINFO)

        except RuntimeError:
            if os.path.exists(TEMP_ZIP):
                os.remove(TEMP_ZIP)
            raise
        except urllib.error.HTTPError as exc:
            raise RuntimeError(f"Étape 2 — HTTP {exc.code} : {exc.reason}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Étape 2 — Erreur réseau : {exc.reason}") from exc
        finally:
            progress.close()

    def extract(self):
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Extraction de l'archive...")

        try:
            with zipfile.ZipFile(TEMP_ZIP, "r") as zf:
                members = zf.namelist()
                total = len(members)

                for i, member in enumerate(members):
                    zf.extract(member, KODI_HOME)
                    percent = int((i + 1) * 100 / total)
                    progress.update(percent, f"Extraction : {member}")

        except zipfile.BadZipFile as exc:
            raise RuntimeError("Archive ZIP invalide ou corrompue.") from exc
        finally:
            progress.close()
            if os.path.exists(TEMP_ZIP):
                os.remove(TEMP_ZIP)
